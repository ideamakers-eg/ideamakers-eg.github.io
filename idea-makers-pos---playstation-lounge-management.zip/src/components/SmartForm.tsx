import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  MessageCircle, 
  Send, 
  Loader2, 
  Globe, 
  User, 
  MapPin, 
  Info,
  ArrowLeft
} from 'lucide-react';
import { SourceSelection, SourceType } from './SourceSelection';
import { useI18n, SUPPORTED_COUNTRIES } from '../i18n';
import { OFFICIAL_PRICING_PACKAGES, formatPriceEGP } from '../pricingConfig';
import { Analytics } from '../lib/analytics';
import './SmartForm.css';
import './package-colors.css';

const packages = OFFICIAL_PRICING_PACKAGES;

const countries = [
  { 
    id: 'egypt', 
    name: 'مصر', 
    flag: '🇪🇬', 
    currency: 'EGP', 
    rate: 1,
    fullName: 'جنيه مصري'
  },
  { 
    id: 'saudi', 
    name: 'السعودية', 
    flag: '🇸🇦', 
    currency: 'SAR', 
    rate: 0.12,
    fullName: 'ريال سعودي'
  },
  { 
    id: 'uae', 
    name: 'الإمارات', 
    flag: '🇦🇪', 
    currency: 'AED', 
    rate: 0.12,
    fullName: 'درهم إماراتي'
  },
  { 
    id: 'qatar', 
    name: 'قطر', 
    flag: '🇶🇦', 
    currency: 'QAR', 
    rate: 0.12,
    fullName: 'ريال قطري'
  },
  { 
    id: 'kuwait', 
    name: 'الكويت', 
    flag: '🇰🇼', 
    currency: 'KWD', 
    rate: 0.01,
    fullName: 'دينار كويتي'
  }
];

const internationalPricing: Record<string, { price: string; currency: string }> = {
  egypt: { price: "10000", currency: "EGP" },
  saudi: { price: "1200", currency: "SAR" },
  uae: { price: "1200", currency: "AED" },
  qatar: { price: "1200", currency: "QAR" },
  kuwait: { price: "100", currency: "KWD" }
};

const whatsappNumber = "201121778205";

interface SmartFormProps {
  initialPackage?: any;
  initialCountry?: any;
}

const SmartForm = ({ initialPackage, initialCountry }: SmartFormProps) => {
  const { country: selectedCountry, setCountry: setSelectedCountry, t } = useI18n();
  const [selectedPackage, setSelectedPackage] = useState(initialPackage || packages[1]);
  const [requestType, setRequestType] = useState<'trial' | 'buy'>('trial');

  // Update state when initialPackage prop changes
  useEffect(() => {
    if (initialPackage) setSelectedPackage(initialPackage);
  }, [initialPackage]);

  useEffect(() => {
    if (initialCountry && initialCountry.id !== selectedCountry.id) {
      setSelectedCountry(initialCountry);
    }
  }, [initialCountry, selectedCountry.id, setSelectedCountry]);

  // Enforce International Package for international countries
  useEffect(() => {
    if (selectedCountry.id !== 'egypt' && selectedPackage.id !== 'international') {
      const intPkg = packages.find(p => p.id === 'international');
      if (intPkg) setSelectedPackage(intPkg);
    }
  }, [selectedCountry.id, selectedPackage.id]);

  const [formData, setFormData] = useState({
    salonName: '',
    clientName: '',
    phone: '',
    address: '',
    marketingCode: '',
    message: ''
  });

  const [selectedSource, setSelectedSource] = useState<SourceType>('');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showRedirect, setShowRedirect] = useState(false);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.salonName.trim()) newErrors.salonName = `${t.forms?.loungeNameLabel || 'اسم الصالة'} مطلوب`;
    if (!formData.clientName.trim()) newErrors.clientName = `${t.forms?.ownerNameLabel || 'اسم العميل'} مطلوب`;
    if (!formData.address.trim()) newErrors.address = 'عنوان الصالة مطلوب';
    
    if (!selectedSource) {
      newErrors.source = 'يرجى اختيار كيف تعرفت علينا';
    } else if (selectedSource === 'affiliate' && !formData.marketingCode.trim()) {
      newErrors.marketingCode = 'يرجى إدخال كود المسوق';
    }
    
    const cleanPhone = formData.phone.trim().replace(/[\s-]/g, '');
    
    const egyptRegex = /^01[0125][0-9]{8}$/;
    const saudiRegex = /^(05|5)[0-9]{8}$/;
    const uaeRegex = /^(05|5)[0-9]{8}$/;
    const qatarRegex = /^(?:974)?[3567][0-9]{7}$/;
    const kuwaitRegex = /^(?:965)?[569][0-9]{7}$/;
    const internationalRegex = /^\+?[0-9]{8,15}$/;

    if (!formData.phone.trim()) {
      newErrors.phone = `${t.forms?.phoneLabel || 'رقم الهاتف'} مطلوب`;
    } else {
      const isValid = egyptRegex.test(cleanPhone) || 
                      saudiRegex.test(cleanPhone) || 
                      uaeRegex.test(cleanPhone) || 
                      qatarRegex.test(cleanPhone) || 
                      kuwaitRegex.test(cleanPhone) || 
                      internationalRegex.test(cleanPhone);
      
      if (!isValid) {
        newErrors.phone = `رقم الهاتف غير صحيح (مثال: ${t.forms?.phonePlaceholder || '01121778205'})`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const code = e.target.value.toUpperCase();
    setFormData(prev => ({ ...prev, marketingCode: code }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const formatCurrency = (val: number | string) => {
    return Number(val).toLocaleString('en-US');
  };

  const getPriceForCountry = (pkgId: string, countryId: string) => {
    const basePkg = packages.find(p => p.id === pkgId);
    if (pkgId === 'international') {
      const verified = internationalPricing[countryId];
      if (verified) {
        return verified;
      }
    }
    // Official package prices are authoritative in EGP
    return {
      price: basePkg ? basePkg.price.toString() : '0',
      currency: 'EGP'
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setShowRedirect(true);
    
    const packageBilingualNames: Record<string, string> = {
      starter: 'Starter Package — باقة البداية',
      professional: 'Professional Package — الباقة الاحترافية',
      international: 'International Package — الباقة المتكاملة (الدولية)'
    };

    const pkgName = packageBilingualNames[selectedPackage.id] || selectedPackage.name;
    const currentPriceData = getPriceForCountry(selectedPackage.id, selectedCountry.id);
    
    const sourceLabels: Record<string, string> = {
      affiliate: 'من خلال مسوق',
      facebook: 'فيسبوك',
      youtube: 'يوتيوب',
      tiktok: 'تيك توك',
      other: 'أخرى'
    };

    const featuresText = selectedPackage.features.map(f => `- ${f}`).join('\n');
    const isAutoSelected = selectedCountry.id !== 'egypt';

    const requestTypeText = requestType === 'trial' 
      ? '🎁 طلب نسخة تجريبية مجانية (3 أيام / 72 ساعة)'
      : '⚡ طلب شراء مباشر وبداية التفعيل الدائم';

    const messageText = `**ملخص الطلب:**

**نوع الطلب:** ${requestTypeText}
**الباقة المختارة:** ${pkgName}
**السعر:** ${formatCurrency(currentPriceData.price)} ${currentPriceData.currency}
**الدولة:** ${selectedCountry.name}
**العملة:** ${currentPriceData.currency}

**مميزات ${pkgName}:**
${featuresText}

**البيانات الأساسية:**
- **اسم الصالة/البراند:** ${formData.salonName}
- **اسم العميل:** ${formData.clientName}
- **رقم الهاتف:** ${formData.phone}
- **عنوان الصالة:** ${formData.address}
- **الرسالة (اختياري):** ${formData.message || 'لا توجد ملاحظات'}

**كيف تعرفت علينا؟**
- ${sourceLabels[selectedSource] || 'غير محدد'}
${formData.marketingCode ? `- **كود المسوق:** ${formData.marketingCode}` : ''}

${isAutoSelected ? '_تم اختيار هذه الباقة بناءً على الدولة المحددة تلقائيًا_' : ''}

_تم إرسال الطلب من الموقع الرسمي لـ IDEA Makers_`;
    
    Analytics.trialFormSubmit(selectedPackage.id, selectedCountry.id);
    const encodedText = encodeURIComponent(messageText);
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedText}`;

    setTimeout(() => {
      window.open(whatsappUrl, '_blank');
      setIsSubmitting(false);
      setShowRedirect(false);
    }, 2000);
  };

  return (
    <section 
      id="smart-form" 
      data-section="request-trial"
      className="smart-form-section scroll-mt-24 sm:scroll-mt-28"
    >
      <div className="container">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="smart-form-container"
        >
          <div className="smart-form-header">
            <h2 className="smart-form-title">استثمار سيادي.. لمرة واحدة</h2>
            <p className="smart-form-subtitle">اختر الباقة التي تناسب طموحك. لا توجد رسوم خفية، لا توجد اشتراكات، لا توجد تبعية.</p>
          </div>

          <form onSubmit={handleSubmit}>
            {/* Request Type Selector */}
            <div className="mb-8 p-1.5 bg-[#0a0a0f] border border-white/10 rounded-2xl">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRequestType('trial')}
                  className={`py-3.5 px-4 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    requestType === 'trial'
                      ? 'bg-gradient-to-r from-primary to-purple-600 text-white shadow-lg shadow-primary/30 border border-primary/50'
                      : 'bg-transparent text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span className="text-base">🎁</span>
                  <span>طلب تجربة مجانية 3 أيام (72 ساعة)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRequestType('buy')}
                  className={`py-3.5 px-4 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    requestType === 'buy'
                      ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/30 border border-amber-500/50'
                      : 'bg-transparent text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span className="text-base">⚡</span>
                  <span>شراء وتفعيل الملكية الدائمة مباشرة</span>
                </button>
              </div>

              {requestType === 'trial' && (
                <div className="mt-3 p-3 bg-primary/10 border border-primary/20 rounded-xl text-xs text-purple-200 font-medium flex items-center gap-2 text-right">
                  <Info className="w-4 h-4 text-primary shrink-0" />
                  <span>تثبيت آمن ومجاني 100% عبر مهندسينا خلال 5 دقائق — تجربة كاملة المزايا بدون بطاقة ائتمان.</span>
                </div>
              )}
            </div>

            {/* Step 1: Package Selection */}
            <div className="step-title">
              <span className="step-number">1</span>
              <span>اختر الباقة المناسبة</span>
            </div>
            <div className="package-grid">
              {packages.map((pkg) => {
                const isInternational = selectedCountry.id !== 'egypt';
                const isDisabled = isInternational && pkg.id !== 'international';
                
                return (
                  <motion.div
                    key={pkg.id}
                    whileHover={!isDisabled ? { y: -5 } : {}}
                    whileTap={!isDisabled ? { scale: 0.98 } : {}}
                    className={`package-card package-${pkg.id === 'professional' ? 'pro' : pkg.id} ${selectedPackage.id === pkg.id ? 'selected' : ''} ${isDisabled ? 'opacity-40 cursor-not-allowed grayscale' : ''}`}
                    onClick={() => !isDisabled && setSelectedPackage(pkg)}
                  >
                    {pkg.badge && (
                      <div className="package-badge">{pkg.badge}</div>
                    )}
                    {isDisabled && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/20 z-10 rounded-[24px]">
                        <span className="bg-black/80 text-white text-[10px] px-2 py-1 rounded-full border border-white/10">
                          متاحة لمصر فقط
                        </span>
                      </div>
                    )}
                    {selectedPackage.id === pkg.id && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="selection-badge"
                      >
                        تم الاختيار
                      </motion.div>
                    )}
                    <div className="package-name">{pkg.name}</div>
                    <div className="package-price">
                      {formatCurrency(getPriceForCountry(pkg.id, selectedCountry.id).price)}
                      <span className="package-currency">
                        {getPriceForCountry(pkg.id, selectedCountry.id).currency}
                      </span>
                    </div>
                    <ul className="package-features">
                      {pkg.features?.map((feature, idx) => (
                        <li key={idx}>
                          <CheckCircle2 className="w-4 h-4" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                );
              })}
            </div>

            {/* Step 2: Country Selection */}
            <div className="step-title">
              <span className="step-number">2</span>
              <span>اختر الدولة</span>
            </div>
            <div className="country-flex">
              {SUPPORTED_COUNTRIES.map((country) => (
                <motion.button
                  key={country.id}
                  type="button"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.95 }}
                  className={`country-btn ${selectedCountry.id === country.id ? 'selected' : ''}`}
                  onClick={() => setSelectedCountry(country)}
                >
                  <span>{country.flag}</span>
                  <span>{country.name}</span>
                </motion.button>
              ))}
            </div>

            {/* Step 3: User Input */}
            <div className="step-title">
              <span className="step-number">3</span>
              <span>البيانات الأساسية</span>
            </div>
            <div className="input-grid form-grid">
              <div className="smart-input-group">
                <input
                  type="text"
                  name="salonName"
                  placeholder=" "
                  className="smart-input"
                  value={formData.salonName}
                  onChange={handleChange}
                />
                <label className="smart-label">اسم الصالة أو البراند</label>
                {errors.salonName && <span className="error-hint">{errors.salonName}</span>}
              </div>

              <div className="smart-input-group">
                <input
                  type="text"
                  name="clientName"
                  placeholder=" "
                  className="smart-input"
                  value={formData.clientName}
                  onChange={handleChange}
                />
                <label className="smart-label">اسم العميل</label>
                {errors.clientName && <span className="error-hint">{errors.clientName}</span>}
              </div>

              <div className="smart-input-group">
                <input
                  type="tel"
                  name="phone"
                  placeholder=" "
                  className="smart-input"
                  value={formData.phone}
                  onChange={handleChange}
                />
                <label className="smart-label">رقم الهاتف</label>
                {errors.phone && <span className="error-hint">{errors.phone}</span>}
              </div>

              <div className="smart-input-group">
                <input
                  type="text"
                  name="address"
                  placeholder=" "
                  className="smart-input"
                  value={formData.address}
                  onChange={handleChange}
                />
                <label className="smart-label">عنوان الصالة</label>
                {errors.address && <span className="error-hint">{errors.address}</span>}
              </div>

              <div className="smart-input-group full">
                <textarea
                  name="message"
                  placeholder=" "
                  className="smart-input smart-textarea"
                  value={formData.message}
                  onChange={handleChange}
                />
                <label className="smart-label">الرسالة (اختياري)</label>
              </div>
            </div>

            {/* Source Selection System */}
            <SourceSelection
              selectedSource={selectedSource}
              onSourceSelect={setSelectedSource}
              marketingCode={formData.marketingCode}
              onCodeChange={(code) => {
                setFormData(prev => ({ ...prev, marketingCode: code }));
              }}
            />
            {errors.source && <div className="error-hint text-center mb-4">{errors.source}</div>}

            {/* Step 4: Dynamic Summary */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="summary-box"
            >
              <div className="summary-title">
                <Info className="w-5 h-5 text-primary" />
                <span>ملخص الطلب</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">نوع الطلب:</span>
                <span className="summary-value font-bold text-primary">
                  {requestType === 'trial' ? '🎁 تجربة مجانية (3 أيام / 72 ساعة)' : '⚡ شراء وتفعيل الملكية الدائمة'}
                </span>
              </div>
              <div className="summary-item">
                <span className="summary-label">الباقة المختارة:</span>
                <span className={`summary-value text-${selectedPackage.id === 'professional' ? 'pro' : selectedPackage.id}`}>{selectedPackage.name}</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">السعر المستحق عند الشراء:</span>
                <span className={`summary-value text-${selectedPackage.id === 'professional' ? 'pro' : selectedPackage.id}`}>
                  {formatCurrency(getPriceForCountry(selectedPackage.id, selectedCountry.id).price)} {getPriceForCountry(selectedPackage.id, selectedCountry.id).currency}
                </span>
              </div>
              <div className="summary-item">
                <span className="summary-label">الدولة والعملة:</span>
                <span className="summary-value">{selectedCountry.name} ({selectedCountry.currency})</span>
              </div>
            </motion.div>

            {/* Step 5: Submit */}
            <div className="submit-actions">
              <button 
                type="submit" 
                className={`smart-submit-btn cursor-pointer ${requestType === 'trial' ? 'bg-gradient-to-r from-primary to-purple-700' : 'bg-gradient-to-r from-amber-500 to-orange-600'}`}
                disabled={isSubmitting || !selectedSource}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="animate-spin w-6 h-6" />
                    <span>جاري التوجيه إلى الواتساب...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-6 h-6" />
                    <span>
                      {requestType === 'trial'
                        ? 'ارسل طلب التجربة المجانية (3 أيام) عبر الواتساب'
                        : 'تأكيد طلب الشراء وتفعيل الملكية الدائمة'}
                    </span>
                  </>
                )}
              </button>
            </div>
          </form>
        </motion.div>
      </div>

      <AnimatePresence>
        {showRedirect && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="redirect-overlay"
          >
            <div className="text-center">
              <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <MessageCircle className="w-10 h-10 text-primary animate-bounce" />
              </div>
              <h3 className="text-3xl font-bold mb-2">تم استلام طلبك!</h3>
              <p className="text-gray-400">جارٍ تحويلك إلى واتساب...</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default SmartForm;
